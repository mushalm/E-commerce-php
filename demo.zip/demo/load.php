<html>
<head>
<title>E&M Store</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.js">
 
	
	</script>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible "content="IE=edge">
	
     <meta name="viewport"content="width=device-width,initial-scale=1.0">

	<link rel="stylesheet" type="text/css" href="loading.css">
	<link rel="stylesheet" type="text/css" href="footer.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">

</head>
 <iframe hidden width="560" height="315" src="https://www.youtube.com/embed/Yf5d_Zx3AaI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
   
<body>

<div class="se-pre-con"id="se-pre-con"></div>
<div class="main">
<nav class="nav">
<div class="navbar">
 <img src="logoem.png"class="logo"height="100px"width="150px" >
   <div class="navitems">
     <div class="menu">
  <ul > 
     <li> <a onclick="myFunction()"href="#">Women</a></li>
     <li> <a onclick="myFunction()"href="#">Men</a></li>
     <li> <a onclick="myFunction()" href="#">Kids</a></li>
	  <li> <a onclick="myFunction()"href="#">Sell</a></li>
  </ul>
  
     </div>
  
  <div class="search">
  <input class="srch" type="search" name=""placeholder="Type to Search">
  <a href="#"><button class="btn">Search</button></a>
 
 <a class="a" onclick="myFunction()" href="#"><img src="user.png"height="40px"width="40px" ></a>
 <a class="a" onclick="myFunction()"href="#"><img src="cart.png"height="40px"width="40px" ></a>
 </div>
    </div> 
	</div>
 </nav>

  <br>
  <br>
  <div class="content">
  <h1>E&M STORE</h1>
 
  </div>
  	
 <div class="form" >
<form action="server.php"method="post" color="white">
 <h2> Login Here</h2>
 
 <input type="email" name="email"placeholder="Enter Email Here">
 <input type="password" name=""placeholder="Enter Password Here"required  id="id_password">
 
 <button onclick="location.href='afterlogin.php'" type="submit"class="btnn"> <a href="#">Login</a></button>
 
 <p class="link">Don't have an account
  <div class="panel">
 <a href="#login_form"id="login_pop">Sign Up </a></p>
  </div>
 <p class="liw">Log in with</p>
 <div class="icon">
 <a href="#"><ion-icon name="logo-facebook"></ion-icon></a>
  <a href="#"><ion-icon name="logo-instagram"></ion-icon></a>
 <a href="#"><ion-icon name="logo-twitter"></ion-icon></a>
 <a href="#"><ion-icon name="logo-google"></ion-icon></a>
<a href="#"><ion-icon name="logo-skype"></ion-icon></a>
   </div>
   </form>
</div>
<a href="#x" class="overlay" id="login_form"></a>
 
 <div class="popup">
 <form action="insert.php"method="post" color="white">
  <h2 align="center">SignUp</h2><br>

 
 <input type="email" name="email"placeholder="Enter Email Here"><br>
 <input type="password" name="pass1"placeholder="Enter Password Here"><br>
 <input type="password" name="pass2"placeholder="Confirm Password Here"><br>

 <button type="submit"class="btnn" align="center"><a href="load.php">Signup</a></button>
 <a class="close" href="#close"></a>
  </form>
  </div>

<i>
<div class="i">
	<input checked type="radio" name="s" style="background-image: url('women.png');" title="Women Aparels">
	<input type="radio" name="s" style="background-image: url('kid.png');" title="Kids Aparels">
	<input type="radio" name="s" style="background-image: url('kid1.png');" title="Kids">
	<input type="radio" name="s" style="background-image: url('men.png');" title="Men Absolute">
	</div>
	</i>
	
<section class="product">
<h2 class="product-category">Woman Apparels</h2>

<button class="pre-btn"><img src="arrow.png"alt=""></button>
<button class="nxt-btn"><img src="arrow.png"alt=""></button>

  <div class="product-container">
     <div class="product-card">
          <div class="product-image">
                    <img src="p1.jpg"class="product-thumb" alt="">
         <button class="card-btn"onclick="location.href='product.html'">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">Lemontart</h2>
		 <p class="product-short-des">LTS279 Lace Peplum</p>
		 <span class="price">RS 2999</span>
		 </div>
     </div>
	 
	 <div class="product-card">
          <div class="product-image">
                    <img src="p2-1.jpg"class="product-thumb" alt="">
         <button class="card-btn"onclick="location.href='product2.html'">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">Lemontart</h2>
		 <p class="product-short-des">3 Piece Gold Foil Block Printed Lawn|LTUS444 </p>
		 <span class="price">RS 2699</span>
		 </div>
	
     </div>
	  <div class="product-card">
          <div class="product-image">
                    <img src="p3-1.jpg"class="product-thumb" alt="">
         <button class="card-btn"onclick="location.href='product3.html'">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">KHAADI</h2>
		 <p class="product-short-des">Khaddar Kurta SKU EST21473 Solid Embroidered Kurta</p>
		 <span class="price">RS 2299</span>
		 </div>
	
     </div>
	  <div class="product-card">
          <div class="product-image">
                    <img src="p2.jpg"class="product-thumb" alt="">
         <button  onclick="myFunction()"class="card-btn">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">J.</h2>
		 <p class="product-short-des">DULL RED COTTON KURTA | JJK-W-37552</p>
		 <span class="price">RS 3999</span>
		 </div>
	
     </div> <div class="product-card">
          <div class="product-image">
                    <img src="p2.jpg"class="product-thumb" alt="">
         <button onclick="myFunction()" class="card-btn">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">J.</h2>
		 <p class="product-short-des">DULL RED COTTON KURTA | JJK-W-37552</p>
		 <span class="price">RS 3999</span>
		 </div>
	
     </div>
	  <div class="product-card">
          <div class="product-image">
                    <img src="p2.jpg"class="product-thumb" alt="">
         <button  onclick="myFunction()"class="card-btn">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">J.</h2>
		 <p class="product-short-des">DULL RED COTTON KURTA | JJK-W-37552</p>
		 <span class="price">RS 3999</span>
		 </div>
	
     </div>
 </div>
 </section>
 <section class="product">
 <h2 class="product-category">Men Apparels</h2>

<button class="pre-btn"><img src="arrow.png"alt=""></button>
<button class="nxt-btn"><img src="arrow.png"alt=""></button>

  <div class="product-container">
     <div class="product-card">
	 
          <div class="product-image">
                    <img src="p1.jpg"class="product-thumb" alt="">
         <button onclick="location.href='product.html'"class="card-btn">View</button>
		 </div>
		 
		 <div class="product-info">
		 <h2 class="product-brand">Lemontart</h2>
		 <p class="product-short-des">LTS279 Lace Peplum</p>
		 <span class="price">RS 2999</span>
		 </div>
     </div>
	 
	 <div class="product-card">
          <div class="product-image">
                    <img src="p2.jpg"class="product-thumb" alt="">
         <button  onclick="myFunction()"class="card-btn">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">J.</h2>
		 <p class="product-short-des">DULL RED COTTON KURTA | JJK-W-37552</p>
		 <span class="price">RS 3999</span>
		 </div>
	
     </div>
	  <div class="product-card">
          <div class="product-image">
                    <img src="p3.jpg"class="product-thumb" alt="">
         <button  onclick="myFunction()"class="card-btn">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">Maria B</h2>
		 <p class="product-short-des">M.Prints MPT-1011-B</p>
		 <span class="price">RS 4699</span>
		 </div>
	
     </div>
	  <div class="product-card">
          <div class="product-image">
                    <img src="p2.jpg"class="product-thumb" alt="">
         <button  onclick="myFunction()" class="card-btn">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">J.</h2>
		 <p class="product-short-des">DULL RED COTTON KURTA | JJK-W-37552</p>
		 <span class="price">RS 3999</span>
		 </div>
	
     </div> <div class="product-card">
          <div class="product-image">
                    <img src="p2.jpg"class="product-thumb" alt="">
         <button  onclick="myFunction()"class="card-btn">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">J.</h2>
		 <p class="product-short-des">DULL RED COTTON KURTA | JJK-W-37552</p>
		 <span class="price">RS 3999</span>
		 </div>
	
     </div>
	  <div class="product-card">
          <div class="product-image">
                    <img src="p2.jpg"class="product-thumb" alt="">
         <button  onclick="myFunction()" class="card-btn">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">J.</h2>
		 <p class="product-short-des">DULL RED COTTON KURTA | JJK-W-37552</p>
		 <span class="price">RS 3999</span>
		 </div>
	
     </div>
 </div>
 </section>
 <section class="product">
 <h2 class="product-category">Kids</h2>

<button class="pre-btn"><img src="arrow.png"alt=""></button>
<button class="nxt-btn"><img src="arrow.png"alt=""></button>

  <div class="product-container">
     <div class="product-card">
          <div class="product-image">
                    <img src="p1.jpg"class="product-thumb" alt="">
         <button  onclick="myFunction()"class="card-btn">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">Lemontart</h2>
		 <p class="product-short-des">LTS279 Lace Peplum</p>
		 <span class="price">RS 2999</span>
		 </div>
     </div>
	 
	 <div class="product-card">
          <div class="product-image">
                    <img src="p2.jpg"class="product-thumb" alt="">
         <button  onclick="myFunction()"class="card-btn">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">J.</h2>
		 <p class="product-short-des">DULL RED COTTON KURTA | JJK-W-37552</p>
		 <span class="price">RS 3999</span>
		 </div>
	
     </div>
	  <div class="product-card">
          <div class="product-image">
                    <img src="p3.jpg"class="product-thumb" alt="">
         <button  onclick="myFunction()"class="card-btn">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">Maria B</h2>
		 <p class="product-short-des">M.Prints MPT-1011-B</p>
		 <span class="price">RS 4699</span>
		 </div>
	
     </div>
	  <div class="product-card">
          <div class="product-image">
                    <img src="p2.jpg"class="product-thumb" alt="">
         <button  onclick="myFunction()"class="card-btn">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">J.</h2>
		 <p class="product-short-des">DULL RED COTTON KURTA | JJK-W-37552</p>
		 <span class="price">RS 3999</span>
		 </div>
	
     </div> <div class="product-card">
          <div class="product-image">
                    <img src="p2.jpg"class="product-thumb" alt="">
         <button  onclick="myFunction()"class="card-btn">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">J.</h2>
		 <p class="product-short-des">DULL RED COTTON KURTA | JJK-W-37552</p>
		 <span class="price">RS 3999</span>
		 </div>
	
     </div>
	  <div class="product-card">
          <div class="product-image">
                    <img src="p2.jpg"class="product-thumb" alt="">
         <button  onclick="myFunction()"class="card-btn">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">J.</h2>
		 <p class="product-short-des">DULL RED COTTON KURTA | JJK-W-37552</p>
		 <span class="price">RS 3999</span>
		 </div>
	
     </div>
 </div>
</section>

 <footer>
 <div class="footer-content">
 <img src="logoem.png"class="logo1"height="100px"width="150px" >

</div>
<p class="footer-title">	About Company</p>
<p class="info">Classified ad posting sites are usually known as newspaper advertisements where buyers and sellers post their requirements and services to their websites. Posting ads on classified websites, not only get the broader audience coverage but also generate more and more business. This website will Provide ease to Buyers and Seller to contact each other directly for the services so that there will be no scam.With the help of Classified ads Listing Website, you can promote your business locally and globally.</p>


</footer>

<script src="home.js"></script>

<script>
function myFunction() {
  alert("Login Required");
}
</script>
<script src="footer.js"></script>
  
 <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
  <script>
   var loader=document.getElementById("se-pre-con");
   window.addEventListener("load",function(){
   loader.style.display="none";
   })
  </script>
</body>
</html>