<html>
<head>
<title>sell</title>
<link rel="stylesheet" type="text/css" href="addproductt.css">
<link rel="stylesheet" type="text/css" href="nav.css">

<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">

</head>
<style>
.styled-table {
    border-collapse: collapse;
    margin: 25px 0;
    font-size: 1.0em;
    font-family: sans-serif;
    min-width: 400px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
}
 table{
		 border:2;
		 width:100%;
		 color:white;
		font-family:sans-serif;
		 font-size:25px;
		 text-align:left;
		   
		 
	 }
	 th{
		 font-family:sans-serif;
		 background: #ff7200;
		 color:black;
	 }
	 tr:nth-child(even).{
		 border-bottom: 1px solid #dddddd;
		 background-color:#f2f2f2}
	 td{
		  border-bottom: 1px solid #ff7200;
		  padding: 12px 10px;
	 }
	 </style>
<body>

<a href="afterlogin.php" class="previous">&laquo; Previous</a><br>
 <a class="a"href="#down5"><img src="cart.png"height="40px"width="40px" ></a>

    </div>
	<form action="server.php"method="post">
  <div class="form">
  <h1 class="text11"><b>Product Details</b></h1>
    <input type="text" name="pname"id="product-name"placeholder="Product name">
  <br>  <input type="text" name="description"id="short-des"placeholder="Short line about the product">
  <br>  <input type="text"name="details" id="des"placeholder="Detail description about product">
<br><br><br>
<!-- product image -->
<div class="product-info">
<div class="product-image"><p class="text">product image</p></div>
<div class="upload-image-sec">
     <p class="text"><img src="camera.png"alt="">upload image</p>
<script>
// upload image handle
let uploadImages = document.querySelectorAll('.fileupload');
let imagePaths = []; 
uploadImages.forEach((fileupload, index) => {
fileupload.addEventListener('change', () => {
const file = fileupload.files[0];
console.log(file);
})
})
</script>

    <div class="upload-catalouge">
<input onclick=""type="file "class="fileupload"id="first-file-upload-btn" name="image"hidden>
<label for="first-file-upload-btn"class="upload-image"></label>
<input type="file "class="fileupload"id="second-file-upload-btn"name="image" hidden>
<label for="second-file-upload-btn"class="upload-image"></label>
<input type="file "class="fileupload"id="third-file-upload-btn"name="image" hidden>
<label for="third-file-upload-btn"class="upload-image"></label>
<input type="file "class="fileupload"id="four-file-upload-btn" name="image"hidden>
<label for="four-file-upload-btn"class="upload-image"></label>
 
</div> 

</div>
<div class="select-sizes">
   <p class="text"name="size">size available</p>
   <div class="sizes">
           
	   
<input type="checkbox"name="size[]" class="size-checkbox" id="s"value="s">		   
<input type="checkbox" name="size[]"class="size-checkbox" id="m"value="m">		   
<input type="checkbox"name="size[]"class="size-checkbox" id="l"value="l">		   
  </div>
</div>

 </div>
<div class="product-price">
   <input type="number"name="actualprice" id="actual-price"placeholder="Actual price"><br><br></div>
    <input type="number"name="discount" id="discount"class="discount"placeholder="Discount-percentage">
	
 <input type="number" name="sellprice"id="sell-price"placeholder="Selling price">



 <br><input type="number"name="stock" id="stock"min="20"placeholder="Item in Stock(Minimun 20)">
 
  <h1 class="text11"><b>Seller Details</b></h1>
 <input id="sellername"    name="sname"   placeholder="Seller Name">
 <br><input id="sellingbrand"name="brand"placeholder="Selling Brand">
 <br><input id="contact"    name="phone" placeholder="Contact Number">
 <br><input id="Address"  name="address"   placeholder="Address">
 
 
<br> <br><br>
 <input type="checkbox" class="checkbox" id="tac" checked>		   
<label for="tac" class="text1">E&M store take 30% from your total sell</label>
 

   <button class="btnn"id="add-btn">Add Product</button>
  <br>  <br>  <br>  <br>  <br>  
   <div id="down5">
   
   <table class="styled-table">
           <tr>
		          <th>Id</th>
		          <th>Name</th>
		          <th>Description</th>
		          <th>Details</th>
		          <th>Size</th>
		          <th>Price</th>
		          <th>Stock</th>
		          
		   </tr>
		   
		  <?php 
		$conn = mysqli_connect("localhost", "root", "", "emstore");
		
		
		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
			$sql = "SELECT id,name,description,detail,size,actualprice,stock from product";

$result=$conn->query($sql);
if($result->num_rows>0){
	while($row=$result->fetch_assoc()){
		echo"<tr><td>".$row["id"]."</td><td>".$row["name"]."</td><td>".$row["description"]."</td><td>".$row["detail"]."</td><td>".$row["size"]."</td><td>".$row["actualprice"]."</td><td>".$row["stock"]."</td></tr>";
	}
	echo"</table>";
}
else{
	echo"0 result";
}
	
	$conn->close();

		?>
   </table>
   </div>
   </form>
   <script language="javascript" src="addproduct.js"></script>

</body>
</html>