<html>
<head>
<title>E&M Store</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.js">
 
	
	</script>
	
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible "content="IE=edge">
	
<meta name="viewport"content="width=device-width,initial-scale=1.0">

	<link rel="stylesheet" type="text/css" href="loading.css">
	<link rel="stylesheet" type="text/css" href="slide.css">
	<link rel="stylesheet" type="text/css" href="footer.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">

</head>
<body>


<nav class="nav">

<div class="navbar">
<a href="#down4"> <img src="logoem.png"class="logo"height="100px"width="150px" ></a>
   <div class="navitems">
     <div class="menu">
  <ul > 
    <li> <a href="#down">Women</a></li>
     <li> <a href="#down1">Men</a></li>
     <li> <a href="#down2">Kids</a></li>
	<li>  <a href="sell.php" class="button-3d">Sell</a></li>
  </ul>
  
     </div>
 
  <div class="search">
  <input class="srch" type="search" name=""placeholder="Type to Search">
  <a href="#"><button class="btn">Search</button></a>
 
 <a class="a" href="#"><img src="user.png"height="40px"width="40px" ></a>
 <a class="a"href="#"><img src="cart.png"height="40px"width="40px" ></a>
 </div>
    </div> 
	</div>
 </nav>
 
 <main class="cd-main container margin-top-xxl">
 <div id="down4">
<div class="untitled">
  <div class="untitled__slides">
    <div class="untitled__slide">
      <div class="untitled__slideBg"></div>
      <div class="untitled__slideContent">
        <span>Kids</span> 
        <span>Apparels</span>
        <a class="button" href="#down2" target="_self">Open</a>
      </div>
    </div>
    <div class="untitled__slide">
      <div class="untitled__slideBg"></div>
      <div class="untitled__slideContent">
        
        <span>E&M Store</span> 
        <span>Search it Buy it Sell it</span>
        <a class="button" href="down1" target="_self">Open</a>
      </div>
    </div>
    <div class="untitled__slide">
      <div class="untitled__slideBg"></div>
      <div class="untitled__slideContent">
        <span>Men</span> 
        <span>Apparels</span>
        <a class="button" href="#down1" target="_self">Open</a>
      </div>
    </div>
    <div class="untitled__slide">
      <div class="untitled__slideBg"></div>
      <div class="untitled__slideContent">
        <span>Women</span> 
        <span>Apparels</span>
        <a class="button" href="#down" target="_self">Open</a>
      </div>
    </div>
  </div>
  <div class="untitled__shutters"></div>
</div></div>
 <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br>
  <div id="down">
       <section class="product">
<h2 class="product-category">Woman Apparels</h2>

<button class="pre-btn"><img src="arrow.png"alt=""></button>
<button class="nxt-btn"><img src="arrow.png"alt=""></button>

  <div class="product-container">
     <div class="product-card">
          <div class="product-image">
                    <img src="p1.jpg"class="product-thumb" alt="">
         <button class="card-btn"onclick="location.href='product.html'">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">Lemontart</h2>
		 <p class="product-short-des">LTS279 Lace Peplum</p>
		 <span class="price">RS 2999</span>
		 </div>
     </div>  
     <div class="product-card">
          <div class="product-image">
                    <img src="a1.jpg"class="product-thumb" alt="">
         <button class="card-btn"onclick="location.href='product A.html'">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">LimeLight</h2>
		 <p class="product-short-des">LimeLight
EMBROIDERED SILK SUIT - White</p>
		 <span class="price">RS 6299</span>
		 </div>
     </div> 
     <div class="product-card">
          <div class="product-image">
                    <img src="b1.jpg"class="product-thumb" alt="">
         <button class="card-btn"onclick="location.href='product B.html'">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">LimeLight</h2>
		 <p class="product-short-des">EMBROIDERED ORGANZA SUIT - Purpel</p>
		 <span class="price">RS 5200</span>
		 </div>
     </div> 
     <div class="product-card">
          <div class="product-image">
                    <img src="g1.jpg"class="product-thumb" alt="">
         <button class="card-btn"onclick="location.href='product G.html'">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">J.</h2>
		 <p class="product-short-des">JJLK-W-JPWK-21-643 FB/Khaddar-Green</p>
		 <span class="price">RS 3832</span>
		 </div>
     </div>  
     <div class="product-card">
          <div class="product-image">
                    <img src="p1.jpg"class="product-thumb" alt="">
         <button class="card-btn"onclick="location.href='product h.html'">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">KHAADI</h2>
		 <p class="product-short-des">Khaas Blue Organza 3 Piece- Blue</p>
		 <span class="price">RS 1519</span>
		 </div>
     </div> 
    <div class="product-card">
          <div class="product-image">
                    <img src="p1.jpg"class="product-thumb" alt="">
         <button class="card-btn"onclick="location.href='product h.html'">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">KHAADI</h2>
		 <p class="product-short-des">Khaas Blue Organza 3 Piece- Blue</p>
		 <span class="price">RS 1519</span>
		 </div>
     </div> 
	 </div>
	 
	 
	 </section>
      </div>
	  <div id="down1">
       <section class="product">
<h2 class="product-category">Men Apparels</h2>

<button class="pre-btn"><img src="arrow.png"alt=""></button>
<button class="nxt-btn"><img src="arrow.png"alt=""></button>

  <div class="product-container">
     <div class="product-card">
          <div class="product-image">
                    <img src="c1.jpg"class="product-thumb" alt="">
         <button class="card-btn"onclick="location.href='product C.html'">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">Limelight</h2>
		 <p class="product-short-des">WASH & WEAR - KAMEEZ SHALWAR - Black</p>
		 <span class="price">RS 3000</span>
		 </div>
     </div> 
 <div class="product-card">
          <div class="product-image">
                    <img src="d1.jpg"class="product-thumb" alt="">
         <button class="card-btn"onclick="location.href='product D.html'">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">Limelight</h2>
		 <p class="product-short-des">WASH & WEAR - COTTON SUIT - White</p>
		 <span class="price">RS 3299</span>
		 </div>
     </div> 
	 
	  <div class="product-card">
          <div class="product-image">
                    <img src="e1.jpg"class="product-thumb" alt="">
         <button class="card-btn"onclick="location.href='product E.html'">View/button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">J.</h2>
		 <p class="product-short-des">light green COTTON SEMI-FORMAL KURTA - JJK-S-31155/S21/JJ7040</p>
		 <span class="price">RS 2632</span>
		 </div>
     </div> 
	  <div class="product-card">
          <div class="product-image">
                    <img src="f1.jpg"class="product-thumb" alt="">
         <button class="card-btn"onclick="location.href='product E.html'">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">J.</h2>
		 <p class="product-short-des">LIGHT GREY BLENDED CASUAL KURTA - JJK-A-33342/S21/JJ7440-CL</p>
		 <span class="price">RS 2219</span>
		 </div>
     </div> 
	   <div class="product-card">
          <div class="product-image">
                    <img src="j1.jpg"class="product-thumb" alt="">
         <button class="card-btn"onclick="location.href='product j.html'">View</button>
		 </div>
		 <div class="product-info">
		 <h2 class="product-brand">Limelight</h2>
		 <p class="product-short-des">COTTON SUIT- Black</p>
		 <span class="price">RS 3339</span>
		 </div>
     </div> 

	 </div>
	 </section>
      </div>
	   <div id="down2">
       <section class="product">
<h2 class="product-category">Kids Wear</h2>

<button class="pre-btn"><img src="arrow.png"alt=""></button>
<button class="nxt-btn"><img src="arrow.png"alt=""></button>

  <div class="product-container">
     <div class="product-card">
          <div class="product-image">
                   				   <img src="l11.jpg"class="product-thumb" alt="">
								      <button class="card-btn"onclick="location.href='product l.html'">View</button>

									  </div>
		 <div class="product-info">
		 <h2 class="product-brand">Ochre</h2>
		 <p class="product-short-des">Light Purple Paper Cotton 3 Piece Suit</p>
		 <span class="price">RS 3295</span>
		 </div>
     </div> 
	 
	  <div class="product-card">
          <div class="product-image">
                   				   <img src="o1.jpg"class="product-thumb" alt="">
								      <button class="card-btn"onclick="location.href='product o.html'">View</button>

									  </div>
		 <div class="product-info">
		 <h2 class="product-brand">Laam</h2>
		 <p class="product-short-des">GARNET CLOTHING | KHUSHI 21 - KIDSWEAR - BLUE TURQUOISE</p>
		 <span class="price">RS 2944</span>
		 </div>
     </div> 

  <div class="product-card">
          <div class="product-image">
                   				   <img src="n1.jpg"class="product-thumb" alt="">
								      <button class="card-btn"onclick="location.href='product n.html'">View</button>

									  </div>
		 <div class="product-info">
		 <h2 class="product-brand">Laam</h2>
		 <p class="product-short-des">BERI AND CORAL | FESTIVE STORY 21 - KIDSWEAR -</p>
		 <span class="price">RS 2400</span>
		 </div>
     </div> 

<div class="product-card">
          <div class="product-image">
                   				   <img src="p11.jpg"class="product-thumb" alt="">
								      <button class="card-btn"onclick="location.href='product p.html'">View</button>

									  </div>
		 <div class="product-info">
		 <h2 class="product-brand">Laam</h2>
		 <p class="product-short-des">GARNET CLOTHING | DHOOP CHAON - KIDSWEAR - TIANA</p>
		 <span class="price">RS 2000</span>
		 </div>
     </div> 


	 </div>
	 </section>
      </div>
 
<script src='footer.js'></script>
<script src='home.js'></script>
 </main>
  
 
  
</body>
</html>
  