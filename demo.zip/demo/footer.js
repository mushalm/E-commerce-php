const createFooter=() =>{
let footer= document.querySelector('footer');
footer.innerHTML='

<div class="footer-content">
 <img src="logoem.png"class="logo1"height="100px"width="150px" >

</div>
<p class="footer-title">	About Company</p>
<p class="info">Classified ad posting sites are usually known as newspaper advertisements where buyers and sellers post their requirements and services to their websites. Posting ads on classified websites, not only get the broader audience coverage but also generate more and more business. This website will Provide ease to Buyers and Seller to contact each other directly for the services so that there will be no scam.With the help of Classified ads Listing Website, you can promote your business locally and globally.</p>

';
}
createFooter();