<!DOCTYPE html>
<html>

<head>
	<title>Insert Page page</title>
</head>

<body>

	<center>
		<?php

	
		$conn = mysqli_connect("localhost", "root", "", "emstore");
		
		
		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
		if(isset($_POST["insert"]))  
 {  
      $file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));  
      $query = "INSERT INTO pimages(imagename) VALUES ('$file')";  
      if(mysqli_query($connect, $query))  
      {  
           echo '<script>alert("Image Inserted into Database")</script>';  
      }  
 }  
		$email = $_REQUEST['email'];
		$pass1 = $_REQUEST['pass1'];
		$confirm = $_REQUEST['pass2'];
		
		
		$sql = "INSERT INTO user VALUES ('','$email',
			'$pass1','$confirm')";
	
			
		if(mysqli_query($conn, $sql)){
			
            header("Location:load.php");
			
		} else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($conn);
		}
				
		// Close connection
		mysqli_close($conn);
		?>
	</center>

</body>

</html>
