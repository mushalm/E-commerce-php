<!DOCTYPE html>
<html>

<head>
	<title>Insert Page page</title>
</head>

<body>
	<center>
		<?php

	
		$conn = mysqli_connect("localhost", "root", "", "emstore");
		
		
		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
		
		
		$pname= $_REQUEST['pname'];
		$des = $_REQUEST['description'];
		$details = $_REQUEST['details'];
		$size = $_REQUEST['size'];
		$actualprice = $_REQUEST['actualprice'];
		$discount = $_REQUEST['discount'];
		$sellprice = $_REQUEST['sellprice'];
		$stock = $_REQUEST['stock'];
	$sname = $_REQUEST['sname'];
		$brand = $_REQUEST['brand'];
		$phone = $_REQUEST['phone'];
		$address = $_REQUEST['address'];
		$checkbox1 = $_POST['size'];
    $chk="";  
    foreach($checkbox1 as $chk1)  
       {  
          $chk.= $chk1.",";  
       }  

		
	$sql1 = "INSERT INTO product VALUES ('','$pname',
	'$des','$details','$chk','$actualprice','$discount','$sellprice','$stock')";
	
	$sql2 = "INSERT INTO sellerinfo VALUES ('','$sname',
			'$brand','$address','$phone')";
			
			mysqli_query($conn, $sql2);
		if(mysqli_query($conn, $sql1)){
			
            header("Location:sell.php");
			
		} else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($conn);
		}
			
		// Close connection
		mysqli_close($conn);
		?>
	</center>

</body>

</html>

